import React, { useState } from 'react';
import Routes from './routes';
import './style.css';

function App(props) {

  return (
    <>
      <Routes />
    </>
  );
}
export default App;
// [usuario, setUsuario]
// constinuar em =>importando  e configurando